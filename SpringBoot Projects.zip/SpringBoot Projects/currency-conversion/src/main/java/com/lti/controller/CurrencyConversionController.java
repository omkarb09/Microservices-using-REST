package com.lti.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.lti.feignproxy.FeignProxy;
import com.lti.model.CurrencyConversion;

@RestController
public class CurrencyConversionController {
	@Autowired
	private FeignProxy proxy;
	
	//http://localhost:8100/currency-converter-feign/from/EUR/to/INR/quantity/10000
	@GetMapping("/currency-converter-feign/from/{from}/to/{to}/quantity/{quantity}")
	@CrossOrigin(origins = "http://localhost:4200")
	public CurrencyConversion currencyConversion(@PathVariable("from")String from, @PathVariable("to") String to, 
			@PathVariable("quantity") BigDecimal quantity)
	{
		CurrencyConversion response = proxy.retrieveExchangeValue(from, to);
		
		return new CurrencyConversion(response.getId(),from,to,response.getConversionMultiple(),
				quantity, quantity.multiply(response.getConversionMultiple()),response.getPort());
	}
}
