package com.lti.security;





/*@Configuration

public class BasicSecurity extends Web{
	
}*/
