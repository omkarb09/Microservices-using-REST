package com.lti.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Student;
import com.lti.repository.StudentRepo;
import com.lti.service.StudentService;

@RestController
@RequestMapping("/RestDemo")
public class RestDemoController 
{
	
	@Autowired
	StudentService service;
	
	//Get all students
	//http://localhost:8080/RestDemo/student
	@GetMapping(path="/student")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Student> getAllStudents()
	{
		List<Student> list = service.findAllStudents();
		return list;
	}
	
	//Get students by id
	//http://localhost:8080/RestDemo/students/1

	@GetMapping(path="/students/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public Student getStudentById(@PathVariable("id") int id)
	{
		Student stud = service.findStudentById(id);
		return stud;
	}
	
	//Add student
	//http://localhost:8080/RestDemo/students
	
	@PostMapping(path="/students")
	@CrossOrigin(origins = "http://localhost:4200")
	public Student addStudent(@RequestBody Student student)
	{
		Student stud = service.addStudent(student);
		return stud;
	}
	
	//Update Student
	//http://localhost:8080/RestDemo/update
	//@PostMapping(path="/update")
	@PutMapping(path="/update")
	@CrossOrigin(origins = "http://localhost:4200")
	public Student updateStudent(@RequestBody Student student)
	{
		Student stud = service.updateStudent(student);
		return stud;
	}
	
	//Delete Student
	//http://localhost:8080/RestDemo/deleteStudent/1
	@DeleteMapping(path="/deleteStudent/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public String deleteStudent(@PathVariable("id") int id)
	{
		service.deleteStudent(id);
		return "Deleted";
		
	}
	
}

/*server.port=9088
spring.datasource.url=jdbc:oracle:thin:@localhost:1521:xe
spring.datasource.username=hr
spring.datasource.password=hr*/